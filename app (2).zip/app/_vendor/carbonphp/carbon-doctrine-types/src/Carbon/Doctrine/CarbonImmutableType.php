<?php

namespace Carbon\Doctrine;

class CarbonImmutableType extends DateTimeImmutableType implements CarbonDoctrineType
{
}
